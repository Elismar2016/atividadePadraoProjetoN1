package trabalho2;

public class Pato extends Ave implements voo,corrida, nado,grasna{

        
    @Override
    public String botar()  {return "";}

    
    public String getNome()  {return "";}

    
    public int getId()  {return 0;}

    @Override
    public String voar()  {return "";}
   

    @Override
    public String correr() {return "";}

    @Override
    public String nadar() 
         {return "";} //To change body of generated methods, choose Tools | Templates.
   

    @Override
    public String grasnar()
         {return "";}//To change body of generated methods, choose Tools | Templates.

    
    
}
