package trabalho2;




public class Dourado extends Peixe implements botarOvo{

    @Override
    String nadar()  {return "";}

    @Override
    public String getNome()  {return "";}

    @Override
    public int getId()  {return 0;}

    @Override
    public String botar()  {return "";}
    
}
