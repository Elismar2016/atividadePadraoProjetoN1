
package trabalho2;


public class Ganso extends Ave implements voo,corrida, nado,grasna{

        
    @Override
    public String botar()  {return "";}

    @Override
    public String voar()  {return "";}
    @Override
    public String grasnar()  {return "";}

    

    public int getId()  {return 0;}

    @Override
    public String correr()  {return "";}

    @Override
    public String nadar()  {return "";}
  

    public String getNome() {
       return "";
    }

    
}
