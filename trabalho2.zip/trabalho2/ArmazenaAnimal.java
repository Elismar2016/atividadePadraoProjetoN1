/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrador
 */
public class ArmazenaAnimal {

    
    

    public ArmazenaAnimal() {
    }
List lista = new ArrayList();
    public List armazenar(int id, String especie, String nome) {

        switch (especie) {

            case "pato":
                Pato patoLocal = new Pato();
                patoLocal.setId(id);
                patoLocal.setNome(nome);
          if ((patoLocal instanceof voo) && (patoLocal instanceof nado) && (patoLocal instanceof grasna)) {
                    lista.add(patoLocal);
                }
                break;
            case "ganso":
                Ganso gansoLocal = new Ganso();
                gansoLocal.setId(id);
                gansoLocal.setNome(nome);
           if ((gansoLocal instanceof voo) && (gansoLocal instanceof nado) && (gansoLocal instanceof grasna)) {
               
                    lista.add(gansoLocal);
                }
               

                break;
        }        
return lista;
    }

       
           
        

}
