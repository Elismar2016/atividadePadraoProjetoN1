package trabalho2;


import trabalho2.corrida;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
public class Cachorro extends Mamifero implements corrida{

    @Override
    String mamar()  {return "";}

    @Override
    public String getNome()  {return "";}

    @Override
    public int getId()  {return 0;}

    @Override
    public String correr()  {return "";}
 
}
