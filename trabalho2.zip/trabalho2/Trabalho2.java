package trabalho2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sistemas
 */
public class Trabalho2 {

    public static void main(String args[]) throws FileNotFoundException, IOException {
 System.out.println("Professor confirmado a leitura como abaixo");
        BufferedReader buff = new BufferedReader(new FileReader("C:/animais.txt"));
        ArmazenaAnimal armazenaAnimal = new ArmazenaAnimal();
           List lista = new ArrayList();
        int id = 0, cont = 0;
        String especie = "";
        String nome;
        String linha = buff.readLine();
        while (linha != null) {

            switch (cont) {
                case 0:

                    id = Integer.parseInt(linha);
                    cont++;
                    break;

                case 1:
                    especie = linha;
                    cont++;
                    break;
                case 2:

                    nome = linha;
                    cont = 0;
                    //  seta o objeto abstrato imagem objeto com id, nome, animal
 System.out.println(id+"|"+ especie+"|"+ nome);
             armazenaAnimal.armazenar(id, especie, nome);
                    break;
            }
            linha = buff.readLine();
        }
        
         System.out.println("mas quando pego o retorno vem so a referencia de memoria");
         lista = armazenaAnimal.lista;
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }
        
      
       
    }
}
