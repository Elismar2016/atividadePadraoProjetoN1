package trabalho2;


import trabalho2.Mamifero;


public class Gato extends Mamifero implements corrida{

    @Override
    String mamar() {return "";}
    @Override
    public String getNome() {return "";}

    @Override
    public int getId() {return 0;}

    @Override
    public String correr() {return "";}
}

