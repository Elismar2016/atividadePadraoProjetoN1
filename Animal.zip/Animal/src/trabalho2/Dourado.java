package trabalho2;




public class Dourado extends Peixe implements botarOvo{

  

    @Override
    public String botar()  {return "";}

  
    
}
