
package trabalho2;


public class Ganso extends Ave{

        
    @Override
    public String botar()  {return "";}

   
    }
  

    

