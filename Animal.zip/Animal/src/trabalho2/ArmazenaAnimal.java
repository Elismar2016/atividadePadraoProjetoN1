
package trabalho2;

import java.util.ArrayList;
import java.util.List;

public class ArmazenaAnimal {

    public ArmazenaAnimal() {
    }
   
    List<Animal> lista = new ArrayList<Animal>();
    public List armazenar(int id, String especie, String nome) {

        switch (especie) {

            case "pato":
                Pato patoLocal = new Pato();
                patoLocal.setId(id);
                patoLocal.setNome(nome);
                lista.add(patoLocal);
                break;
                
            case "ganso":
                Ganso gansoLocal = new Ganso();
                gansoLocal.setId(id);
                gansoLocal.setNome(nome);
               lista.add(gansoLocal);
                break;
                
             case "aguia":
                Aguia aguiaLocal = new Aguia();
                aguiaLocal.setId(id);
                aguiaLocal.setNome(nome);
                lista.add(aguiaLocal);
               break;
               
            case "betta":
                Betta bettaLocal = new Betta();
                bettaLocal.setId(id);
                bettaLocal.setNome(nome);
               lista.add(bettaLocal);
               break;
               
            case "morcego":
                Morcego morcegoLocal = new Morcego();
                morcegoLocal.setId(id);
                morcegoLocal.setNome(nome);
               lista.add(morcegoLocal);
               break;
            case "cachorro":
                Cachorro cachorroLocal = new Cachorro();
                cachorroLocal.setId(id);
                cachorroLocal.setNome(nome);
               lista.add(cachorroLocal);
               break;
            case "dourado":
                Dourado douradoLocal = new Dourado();
                douradoLocal.setId(id);
                douradoLocal.setNome(nome);
               lista.add(douradoLocal);
               break;
            case "gato":
                Gato gatoLocal = new Gato();
                gatoLocal.setId(id);
                gatoLocal.setNome(nome);
               lista.add(gatoLocal);
               break;
            
        }        
return lista;
    }

       
           
        

}
