package trabalho2;

public class Pato extends Ave {

        
    @Override
    public String botar()  {return "";}

    
    
    

 
    
    
}
