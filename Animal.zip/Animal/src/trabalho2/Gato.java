package trabalho2;


import trabalho2.Mamifero;


public class Gato extends Mamifero {

    @Override
    public String mamar() {return "";}
   

   

   
}

