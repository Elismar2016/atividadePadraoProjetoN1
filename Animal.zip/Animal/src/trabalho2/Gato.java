package trabalho2;


import trabalho2.Mamifero;


public class Gato extends Mamifero implements corrida{

    @Override
    public String mamar() {return "";}
   

    @Override
    public String correr() {return "";}
}

