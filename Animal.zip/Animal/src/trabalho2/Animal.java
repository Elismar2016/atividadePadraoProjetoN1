package trabalho2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
abstract class Animal{
  private String nome;
    private    int id;
  private EmitirSom emitirSom;      
    private Locomocao locomocao;    
        
 	Animal(){ };   //allow

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the emitirSom
     */
    public EmitirSom getEmitirSom() {
        return emitirSom;
    }

    /**
     * @param emitirSom the emitirSom to set
     */
    public void setEmitirSom(EmitirSom emitirSom) {
        this.emitirSom = emitirSom;
    }

    /**
     * @return the locomocao
     */
    public Locomocao getLocomocao() {
        return locomocao;
    }

    /**
     * @param locomocao the locomocao to set
     */
    public void setLocomocao(Locomocao locomocao) {
        this.locomocao = locomocao;
    }

}