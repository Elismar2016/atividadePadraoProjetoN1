/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

/**
 *
 * @author Sistemas
 */
public class Betta extends Peixe implements botarOvo{

    @Override
    String nadar() {
        return "Nado em aguas profundas";   }
    

    

    @Override
    String getNome() {
       return "Betinho";   }

    @Override
    public String botar() {
       return "Boto ovinho  ";   }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
