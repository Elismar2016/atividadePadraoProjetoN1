package trabalho2;


import trabalho2.Mamifero;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
public class Gato extends Mamifero implements corrida{
    
    public String falar() {
                return "Miau Miau";
        }
    @Override
        public String getNome(){return "Felix";}

    @Override
    String mamar() {
     return "Sou mamifero a vida toda"; }

    @Override
    public String correr() {
     return "Corro em 4 patas no telhado"; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

