package trabalho2;


import trabalho2.corrida;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
public class Cachorro extends Mamifero implements corrida{
 
        public String falar() {
                return "Falo: Arf! Arf!";
        }
        @Override
        public String getNome(){return "Meu nome é: Toto";}

    @Override
    String mamar() {
   return "Sou mamifero";
    }

    @Override
    public String correr() {
        return "Corro em 4 patas"; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
