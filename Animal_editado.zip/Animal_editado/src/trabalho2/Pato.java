package trabalho2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
public class Pato extends Ave implements voo,corrida, nado,grasna{
 public String falar() {
                return "Clac Clac!  ";
        }
 @Override
        public String getNome(){return "Donald  ";}
 
 @Override
    public String voar() {
    return   "Voou alto";    
    }

 @Override
    public String botar() {
  return "Boto Ovo grande de duas gemas";  }

    @Override
    public String correr() {
       return "Corro em duas patas"; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String nadar() {
        return "nado do pato";
    }

    @Override
    public String grasnar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
