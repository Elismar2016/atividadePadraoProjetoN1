package trabalho2;




public class Dourado extends Peixe implements botarOvo{
        public String falar() {
                return "Mexo a boca";
        }  
        @Override
        public String getNome(){return "Meu nome é: Douradinho  ";}

    @Override
    String nadar() {
   return "Nado no mar";  }

    @Override
    public String botar() {
    return "Boto ovas  ";  }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
