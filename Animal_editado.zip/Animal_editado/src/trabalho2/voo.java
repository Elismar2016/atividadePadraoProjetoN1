package trabalho2;



public interface voo {

    public abstract String voar();
       
}
