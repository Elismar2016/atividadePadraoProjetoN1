package trabalho2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
public class Morcego extends Mamifero implements voo{

    @Override
    String mamar() {
      return "Sou mamifero"; }

    String falar() {
              return " Nao falo";
       }

    @Override
    String getNome() {
        return "Meu nome é: Batman ";
          }

    @Override
    public String voar() {
     return "Voo  a noite"; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
