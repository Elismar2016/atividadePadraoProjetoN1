/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrador
 */
public class ArmazenaAnimal {
    
  List<voo> listaVoador;
  List<nado>listaNado;
  List<grasna>listaGrasna;
  
  public ArmazenaAnimal(){
		listaVoador = new ArrayList<voo>();
                listaNado = new ArrayList<nado>();
                listaGrasna = new ArrayList<grasna>();
	}
    public void armazenar(int id, String especie, String nome) {
       
	    switch (especie){
			
	    	case "pato":            			
	      		Pato patoLocal = new Pato();
	    		patoLocal.setId(id);
                        patoLocal.setNome(nome);
                        if(patoLocal instanceof voo){
                           listaVoador.add(patoLocal); 
                        }
                       
                        listaNado.add(patoLocal);
				break;
	    	case "ganso":
	    		Ganso gansoLocal = new Ganso();
	    		gansoLocal.setId(id);
                        gansoLocal.setNome(nome);
                        listaVoador.add(gansoLocal);
                        break;            	
	    } 
		
	}
	
	

	public List<voo> getListaVoador() {
		return listaVoador;
	}

	public void setListaFiguras(List<Figura> listaFiguras) {
		this.listaFiguras = listaFiguras;
	}
	
	
	
}
