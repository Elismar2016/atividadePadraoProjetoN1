package trabalho2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Sistemas
 */
abstract class Peixe extends Animal{
  abstract String nadar();
     int i;
	Peixe(int i){ this.i = 0;};   //allow

 	Peixe(){ };   //allow
    
}
